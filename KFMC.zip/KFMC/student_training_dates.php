<!DOCTYPE html>
<html lang="en">
<head>
     <title>التجمع الصحي الثاني</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/main.css">
     <link href="images/logo.png" rel="icon" type="image/png" />

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-style.css">
     <script src="js/script.js"></script> 
<script>
    function addWeeksToDate(){
        var start = document.fm.start.value;
        var num = 8; 
        const newDate = new Date(start); 
        // Calculate the number of milliseconds in a week
        const millisecondsInWeek = 7 * 24 * 60 * 60 * 1000; 
        // Add the specified number of weeks to the date
        newDate.setTime(newDate.getTime() + (num * millisecondsInWeek)); 
        document.getElementById("finish").innerHTML = newDate;
    }
</script>
</head>
<?php
    $reqID = $_GET['req'];
?>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>  
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="header-icons" align="right">
                    <a href="logout.php"  title="Logout"><i class="fa fa-sign-out"></i>&nbsp; خروج</a>
                    <a href="en/student_training_dates.php"  title="Lang"><img src="images/lang.png" style="width:18px; height:18px;">&nbsp;EN</a>
               </div>
               <img class="nav navbar-right" src="images/health_cluster.png" style="width:40%;" dir="right">
               <br>
               <br>
              <div class="navbar-header">
                    <nav class="main-menu">
                         <ul>
                              <li><a href="index.php">الرئيسية</a></li>
                              <li><a href="index.php#about">البرنامج</a></li>
                              <li><a href="index.php#team">الخدمات</a></li>
                         </ul>
                    </nav>
               </div>        
          </div>
     </section>

     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <form id="contact-form" name="fm" role="form" action="php/request_dates.php" method="post">
                              <div style="margin-top: 30px;" dir="rtl" class="section-title">
                                   <h2> تاريخ التدريب<small> قم بتحديد تاريخ فتح وإغلاق التدريب </small></h2>
                              </div>

                        <div style="margin-top: 50px;" class="col-md-12 col-sm-12">
                            <input type="date" class="form-control" placeholder="فتح التدريب" id="start" name="start_date" onChange="addWeeksToDate()" required="">                   
                            <input type="date" class="form-control" placeholder="نهاية التدريب" id="finish" name="end_date" required="">
                            <input type="hidden" class="form-control" name="req_id" value="<?php echo $reqID; ?>">
                        </div>
                              <div style="margin-top:30px;" class="col-md-4 col-sm-12">
                                   <input style="font-weight: bold; font-size: 16px;" type="submit" class="form-control" name="submit" value="حفظ">
                                   <br>
                              </div>
                        </form>
                        
                    </div>
                    

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                             <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>

                   

               </div>
          </div>
     </section>       


     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>حول تجمع الرياض الصحي الثاني </h2>
                              </div>
                              <address>
                                   <p>المملكة العربية السعودية</p>
                              </address>

                              <ul class="social-icon">
                                   <li><a href="https://www.facebook.com/Cluster2Riyadh" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://ca.linkedin.com/company/second-health-cluster" class="fa fa-linkedin"></a></li>
                                   <li><a href="https://www.instagram.com/cluster2_riyadh/" class="fa fa-instagram"></a></li>
                                   <li><a href="https://x.com/Cluster2_Riyadh" class="fa fa-twitter"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2024 KFMC</p>
                                  
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>معلومات الاتصال</h2>
                              </div>
                              <address>
                                   <p><i class="fa fa-phone"></i> &nbsp;8001277000</p>
                                   <p><i class="fa fa-envelope"></i> &nbsp;<a href="mailto:KFMC">info@rc2.med.sa</a></p>
                              </address>
                         </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                         <div class="footer_menu" style="margin-top: -40px;">
                              <h2 style="color: #FFFFFF;">روابط هامة</h2>
                                   <p><a href="https://www.moh.gov.sa/Pages/Default.aspx"> وزارة الصحة </a></p>
                                   <p><a href="https://www.kfmc.med.sa/">مدينة الملك فهد الطبية</a></p>
                                   <p><a href="https://shc.gov.sa/Arabic/Pages/default.aspx"> المجلس الصحي السعودي </a></p> 
                                   <p><a href="https://www.who.int/ar/home">منظمة الصحة العالمية  </a></p>                                  
                                 
                         </div>
                    </div>

                   
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>