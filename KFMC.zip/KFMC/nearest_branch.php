<!DOCTYPE html>
<html lang="en">
<head>
     <title>التجمع الصحي الثاني</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/main.css">
     <link href="images/logo.png" rel="icon" type="image/png" />

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-style.css">
     <script src="js/script.js"></script> 
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>  
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="header-icons" align="right">
                    <a href="login.html"  title="Login"><i class="fa fa-user"></i>&nbsp; دخول</a>
                    <a href="en/nearest_branch.php"  title="Lang"><img src="images/lang.png" style="width:18px; height:18px;">&nbsp;EN</a>
               </div>
               <img class="nav navbar-right" src="images/health_cluster.png" style="width:40%;" dir="right">
               <br>
               <br>
              <div class="navbar-header">
                    <nav class="main-menu">
                         <ul>
                              <li><a href="index.php">الرئيسية</a></li>
                              <li><a href="index.php#about">البرنامج</a></li>
                              <li><a href="index.php#team">الخدمات</a></li>
                              <li><a href="apply_training.php">التقديم</a></li>
                         </ul>
                    </nav>
               </div>        
          </div>
     </section>

     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-sm-12">
                        <?php
                              include("php/connect.php");
                              $lat = $_GET['lat'];
                              $lng = $_GET['lng'];
                              $sql = mysqli_query($connect, "select `branch_name`,`branch_city`, `health_cluster`,
                              `branch_email`,`branch_location`, `branch_lat`, `branch_lng`, 
                              (3959 * acos(cos(radians($lat)) * cos(radians(branch_lat)) * cos(radians(branch_lng) - radians($lng)) + sin(radians($lat)) * sin(radians(branch_lat)))) AS distance  from `branch` ORDER BY distance LIMIT 1");
                              $num = mysqli_num_rows($sql);
                              if ($num > 0) { 
                                   while ($row = mysqli_fetch_array($sql)) {
                                   ?>
                                   <div style="margin-top: 20px;" dir="rtl" class="section-title">
                         <h2>  الفرع الأقرب <small> بيانات أقرب فرع لموقعك الحالي</small></h2>
                              </div>   
                        <div style="margin-top: 20px; width: 100%;">
                            <br>
                            <div style="border: 2px solid #FFFFFF; padding: 10px; width: 100%; border-radius:20px;
                            background: linear-gradient(to right, #909090, #105968);" dir="rtl">
                                <h3 style="color: #f9f9f9;"><font color="#CCCCCC">الفرع:</font> <?php echo $row["branch_name"]; ?>
                                <small style="color: #f9f9f9;">&nbsp;&nbsp;(على بعد <?php echo $row["distance"]; ?>  ميل)</small></h3>
                                <table width="100%"><tr>
                                    <td width="50%"><h4><font color="#CCCCCC"> المدينة:</font> <?php echo $row["branch_city"]; ?></h4></td>
                                    <td width="50%"><h4><font color="#CCCCCC">المركز الصحي:</font> <?php echo $row["health_cluster"]; ?></h4></td>
                                </tr>
                                <tr>
                                    <td width="50%"><h4><font color="#CCCCCC">البريدالالكتروني: </font><?php echo $row["branch_email"]; ?></h4></td>
                                    <td width="50%"><h4><font color="#CCCCCC"> الموقع: </font><a href="<?php echo $row["branch_location"]; ?>" target="_blank">عرض الموقع </a></h4></td>
                                </tr></table>
                            </div>
                                   <?php
                                   }
                              } else { 
                                   echo "No locations found"; 
                              }
                        ?>
                        
                        </div>   
                    </div>
                    

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                             <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>

                   

               </div>
          </div>
     </section>       


     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>حول تجمع الرياض الصحي الثاني </h2>
                              </div>
                              <address>
                                   <p>المملكة العربية السعودية</p>
                              </address>

                              <ul class="social-icon">
                                   <li><a href="https://www.facebook.com/Cluster2Riyadh" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://ca.linkedin.com/company/second-health-cluster" class="fa fa-linkedin"></a></li>
                                   <li><a href="https://www.instagram.com/cluster2_riyadh/" class="fa fa-instagram"></a></li>
                                   <li><a href="https://x.com/Cluster2_Riyadh" class="fa fa-twitter"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2024 KFMC</p>
                                  
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>معلومات الاتصال</h2>
                              </div>
                              <address>
                                   <p><i class="fa fa-phone"></i> &nbsp;8001277000</p>
                                   <p><i class="fa fa-envelope"></i> &nbsp;<a href="mailto:KFMC">info@rc2.med.sa</a></p>
                              </address>
                         </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                         <div class="footer_menu" style="margin-top: -40px;">
                              <h2 style="color: #FFFFFF;">روابط هامة</h2>
                                   <p><a href="https://www.moh.gov.sa/Pages/Default.aspx"> وزارة الصحة </a></p>
                                   <p><a href="https://www.kfmc.med.sa/">مدينة الملك فهد الطبية</a></p>
                                   <p><a href="https://shc.gov.sa/Arabic/Pages/default.aspx"> المجلس الصحي السعودي </a></p> 
                                   <p><a href="https://www.who.int/ar/home">منظمة الصحة العالمية  </a></p>                                  
                                 
                         </div>
                    </div>

                   
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>