<!DOCTYPE html>
<html lang="en">
<head>
     <title>التجمع الصحي الثاني</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link href="images/logo.png" rel="icon" type="image/png" />

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/main.css">
     <link rel="stylesheet" href="css/templatemo-style.css">
     <script>
          function clearCookies() 
          { 
          const cookies = document.cookie.split(";");
          for (let i = 0; i < cookies.length; i++) 
          { 
               const cookie = cookies[i]; 
               const eqPos = cookie.indexOf("="); 
               const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie; 
               document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/"; 
          } 
          }
     setInterval(clearCookies, 60 * 60 * 1000); // 60 minutes * 60 seconds * 1000 milliseconds
     </script>
     <style>
           body.lock-scroll { 
               overflow: hidden;
                /* Disable scrolling */ 
               }
          .rectangle { 
               width: 200px; 
               height: 250px;
               background-color: #FFFFFF; 
               border: 2px solid #d9d9d9; 
               transition: border-color 0.3s, box-shadow 0.3s;
               padding-top: 30px;
               } 
               .rectangle:hover { 
               border-color: #1596D8; 
               box-shadow: 0 0 20px #1596D8; 
               }
     </style>

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>  
          </div>
     </section>
    <?php 
    include('php/connect.php');
    $open_dates = mysqli_query($connect, "SELECT * FROM `training_dates`");
    if($record = mysqli_fetch_array($open_dates)){
        $open_date = $record['train_open_date'];
        $close_date = $record['train_close_date'];
        $date = date('y-m-d');
        $today = new DateTime($date);
        $openDate = new DateTime($open_date);
        $closeDate = new DateTime($close_date);
        if(($today >= $openDate) && ($today <= $closeDate)){
            $open = "1"; 
        }else{
            $open = "0";
        }
    }
    ?>
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
            <div class="header-icons" align="left">
                <?php
                    if($open == "1"){
                ?>
                    <h4 style="color:#5E9EAA;" dir="rtl">التسجيل مفتوح من <?php echo $open_date; ?> إلى <?php echo $close_date; ?></h4>
                    <?php
                        }else if($open == "0"){
                    ?>
                    <h4 style="color:#f14851;" dir="rtl">التسجيل مغلق</h4>
                    <?php
                        }
                    ?>

            </div>
                <div class="header-icons" align="right">
                    <a href="login.html"  title="Login"><i class="fa fa-user"></i>&nbsp; دخول</a>
                    <a href="en/index.php"  title="Lang"><img src="images/lang.png" style="width:18px; height:18px;">&nbsp;EN</a>
               </div>
               
               <img class="nav navbar-right" src="images/health_cluster.png" style="width:40%;" dir="right">
               <br>
               <br>              
               <div class="navbar-header">
                    <nav class="main-menu">
                    <ul>
                         <li><a href="index.php">الرئيسية</a></li>
                         <li><a href="index.php#about">البرنامج</a></li>
                         <li><a href="index.php#team">الخدمات</a></li>
                         <li><a href="apply_training.php">التقديم</a></li>
                    </ul>
               </nav>
               </div>
           </div>

          </div>
          <div class="fixed-icon"> 
               <a href="https://api.whatsapp.com/send/?phone=9668001277000&text&type=phone_number&app_absent=0">
                    <img src="images/customer_service.png" alt="Icon" style="width:90%; height: 90%;"></a>
          </div>
     </section>
     <!-- HOME -->
     <section id="home">
          <div class="row">
                    <div class="owl-carousel owl-theme home-slider">
                         <div class="item item-first">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1>أنواع التدريب</h1>
                                             <h3 style="font-weight: bold; font-size: 18px;">تعرف على أنواع التدريب المتاحة</h3>
                                             <a href="#team" style="font-weight: bold; font-size: 18px;" class="section-btn btn btn-default smoothScroll">أنواع التدريب </a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-second">
                              <div class="caption">
                                   <div class="container">
                                        <div>
                                             <h1 style="margin-left: 600px;">الالتحاق بالتدريب </h1>
                                             <h3 style="font-weight: bold; font-size: 18px;margin-left: 600px;">تعرف على أهداف التدريب</h3>
                                             <a style="font-weight: bold; font-size: 18px;margin-left: 600px;" href="#about" class="section-btn btn btn-default smoothScroll">أهداف التدريب  </a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-third">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1>التسجيل بالتدريب</h1>
                                             <h3 style="font-weight: bold; font-size: 18px;">انتقل للتسجيل في أحد برامج تدريبنا </h3>
                                             <a style="font-weight: bold; font-size: 18px;" href="apply_training.php" class="section-btn btn btn-default smoothScroll">التسجيل</a>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
          </div>
     </section>


     <!-- ABOUT -->
     <section id="about">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="about-info">
                              <h2>حول البرنامج</h2>

                              <figure>
                                   <span><i class="fa fa-users"></i></span>
                                   <figcaption>
                                        <h3>أهداف البرنامج</h3>
                                        <br>
                                   <ul>
                                        <li style="margin-left: 75px;" dir="rtl" align="justify">
                                             دعم الطلاب عن طريق المواءمة بين الدراسة الأكاديمية والتطبيق العملي في بيئة عمل فعلية.
                                        </li>
                                        <li style="margin-left: 75px;" dir="rtl" align="justify">
                                             رفع مستوى المعرفة والمهارات التخصصية والشخصية لدى الطلاب الجامعيين عبر إتاحة الفرصة لهم باكتساب مهارات جديدة ورفع مستوى التفكير الإبداعي والقدرة على العمل الجماعي. 
                                        </li>
                                        <li style="margin-left: 75px;" dir="rtl" align="justify">
                                             تمكين الكوادر الوطنية من الممارسة العملية في تخصصاتهم وفق أفضل الممارسات المهنية.
                                        </li>
                                        <li style="margin-left: 75px;" dir="rtl" align="justify">
                                             تمكينهم من ممارسة المهارات التخصصية وتشمل مهارات اتخاذ القرار وحل المشاكل في بيئة العمل.
                                        </li>
                                        <li style="margin-left: 75px;" dir="rtl" align="justify">
                                             تعزيز العلاقة الاستراتيجية مع الجامعات والمعاهد داخل المملكة وخارجها.
                                        </li>
                                        <li style="margin-left: 75px;" dir="rtl" align="justify">
                                             دعم مخرجات التعليم الجامعي لمواكبة احتياجات سوق العمل.
                                        </li>
                                   </ul>
                                   </figcaption>
                              </figure>

                              <figure>
                                   <span><i class="fa fa-file"></i></span>
                                   <figcaption>
                                        <h3> الوثائق المطلوبة</h3>
                                        <br>
                                   <ul>
                                        <li style="margin-right: 10px;" dir="rtl" align="justify">
                                             تعبئة نموذج طلب التدريب.
                                        </li>
                                        <li style="margin-right: 10px;" dir="rtl" align="justify">
                                             صورة من بطاقة الأحوال المدنية.
                                        </li>
                                        <li style="margin-right: 10px;" dir="rtl" align="justify">
                                             نسخة من السجل الأكاديمي.
                                        </li>
                                        <li style="margin-right: 10px; padding-left:30px;" dir="rtl" align="justify">
                                             خطاب من الجامعة ينص على أن برنامج التدريب التعاوني متطلب مع توضيح تاريخ بداية التدريب ونهايته.
                                        </li>
                                   </ul>

                                   </figcaption>
                              </figure>
                         </div>
                    </div>

                    <div style="margin-top: 90px;" class="col-md-offset-1 col-md-4 col-sm-12">
                         <figure>
                              <span><i class="fa fa-info"></i></span>
                              <figcaption style="margin-top: 30px;">
                                   <h3>السياسة</h3>
                                   <p align="justify" dir="rtl" style="margin-left: 75px;">
                                        تطبق هذه السياسة على الكفاءات الوطنية من طلاب الجامعات والمعاهد والكليات الداخلية والخارجية الذين يشترط عليهم إكمال متطلب التدريب التعاوني والتطبيق العملي قبل التخرج                                         </p>
                              </figcaption>
                         </figure>
                         <figure>
                              <span><i class="fa fa-check"></i></span>
                              <figcaption>
                                   <h3>استيفاء شروط القبول</h3>
                                   <br>
                              <ul>
                                   <li dir="rtl" align="justify">
                                        توافق التخصص مع المجالات المعتمدة في التدريب التعاوني 
                                   </li>
                                   <li dir="rtl" align="justify">
                                        شروط القبول
                                        ألا تقل مدة التدريب المطلوبة من الجامعة عن 8 أسابيع
                                   </li>
                                   <li dir="rtl" align="justify">
                                        أن يكون المتقدم سعودي الجنسية. 
                                   </li>
                                   <li dir="rtl" align="justify">
                                        ألا يكون المتقدم قد تخرج وحقق متطلبات برنامج التدريب التعاوني
                                   </li>
                              </ul>

                              </figcaption>
                         </figure>

                    </div>

               </div>
          </div>
     </section>


     <!-- TEAM -->
     <section style="background: #ffffff;" id="team">
          <div class="container">
               <div class="row" align="center">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>  خدماتنا  </h2>
                         </div>
                    </div>
                    <table width="70%" style="margin-left: 100px;"><tr>
                    <td>
                    <div class="rectangle">
                         <div align="center">
                              <a href="nearest_branch.html"><img src="images/nearby.png" style="height:100px; width:100px; padding-top: 10px;" class="img-responsive" alt=""></a>
                         </div>
                         <h3 align="center"><a href="nearest_branch.html">أقرب مركز</a></h3>
                    </div>
               </td><td>
                    <div class="rectangle">
                         <div align="center">
                              <a href="all_branches.html"><img src="images/branches.png" style="height:100px; width:100px; padding-top: 10px;" class="img-responsive" alt=""></a>
                         </div>
                         <h3 align="center"><a href="all_branches.html"> المراكز الصحية</a></h3>
                    </div>
               </td><td>
                    <div class="rectangle">
                         <div align="center">
                              <a href="about_health.html"><img src="images/logo.png" style="height:100px; width:100px; padding-top: 10px;" class="img-responsive" alt=""></a>
                         </div>
                         <h3 align="center"><a href="about_health.html"> حول التجمع الصحي </a></h3>
                    </div>
               </td></tr></table>
               </div>
          </div>
     </section>


     <!-- Courses -->
     <section id="courses">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1> الفعاليات<small style="color: #1596D8; font-size: 15px;">الفعاليات القادمة</small></h1>
                         </div>

                         <div class="owl-carousel owl-theme owl-courses">
                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 18-12-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">اليوم العالمي للغة العربية</a></h3></td>
                                                       <td width="40%"><img src="images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                                 <a href="activity_detail.php?name=اليوم العالمي للغة العربية&date=18-12-2024"><span>عرض المزيد</span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 16-12-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">اليوم العالمي لحقوق الإنسان</a></h3></td>
                                                       <td width="40%"><img src="images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                                 <a href="activity_detail.php?name=اليوم العالمي لحقوق الإنسان&date=16-12-2024"><span>عرض المزيد</span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 25-12-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">اليوم العالمي للمدير </a></h3></td>
                                                       <td width="40%"><img src="images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                                 <a href="activity_detail.php?name=اليوم العالمي للمدير&date=25-12-2024"><span>عرض المزيد</span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 01-10-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">اليوم العالمي للقهوة </a></h3></td>
                                                       <td width="40%"><img src="images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                                 <a href="activity_detail.php?name=اليوم العالمي للقهوة&date=01-10-2024"><span>عرض المزيد</span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                         </div>

               </div>
          </div>
     </section> 

     <section id="testimonial">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>الإعتمادات والجوائز <small style="color: #1596D8; font-size: 15px;">شهادات الجودة والجوائز</small></h2>
                         </div>

                         <div class="owl-carousel owl-theme owl-client">
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify2.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify1.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify3.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify4.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify5.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify6.gif" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify7.jpg" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify8.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify9.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify10.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify11.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify12.jpg" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify13.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify14.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="images/certify15.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                         </div>

               </div>
          </div>
     </section> 


     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>حول تجمع الرياض الصحي الثاني </h2>
                              </div>
                              <address>
                                   <p>المملكة العربية السعودية</p>
                              </address>

                              <ul class="social-icon">
                                   <li><a href="https://www.facebook.com/Cluster2Riyadh" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://ca.linkedin.com/company/second-health-cluster" class="fa fa-linkedin"></a></li>
                                   <li><a href="https://www.instagram.com/cluster2_riyadh/" class="fa fa-instagram"></a></li>
                                   <li><a href="https://x.com/Cluster2_Riyadh" class="fa fa-twitter"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2024 KFMC</p>
                                  
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>معلومات الاتصال</h2>
                              </div>
                              <address>
                                   <p><i class="fa fa-phone"></i> &nbsp;8001277000</p>
                                   <p><i class="fa fa-envelope"></i> &nbsp;<a href="mailto:KFMC">info@rc2.med.sa</a></p>
                              </address>
                         </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                         <div class="footer_menu" style="margin-top: -40px;">
                              <h2 style="color: #FFFFFF;">روابط هامة</h2>
                                   <p><a href="https://www.moh.gov.sa/Pages/Default.aspx"> وزارة الصحة </a></p>
                                   <p><a href="https://www.kfmc.med.sa/">مدينة الملك فهد الطبية</a></p>
                                   <p><a href="https://shc.gov.sa/Arabic/Pages/default.aspx"> المجلس الصحي السعودي </a></p> 
                                   <p><a href="https://www.who.int/ar/home">منظمة الصحة العالمية  </a></p>                                  
                                 
                         </div>
                    </div>

                   
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>