<?php
     session_start();       
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <title>التجمع الصحي الثاني</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="../css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/font-awesome.min.css">
     <link rel="stylesheet" href="../css/owl.carousel.css">
     <link rel="stylesheet" href="../css/owl.theme.default.min.css">
     <link href="../images/logo.png" rel="icon" type="image/png" />

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="../css/main.css">
     <link rel="stylesheet" href="../css/templatemo-style.css">
     <script src="../js/script.js"></script> 

     <script>
          function Validate()
          {
               if(document.fm.city.value == "0")
               {
                    document.getElementById("wrong").style.display ="block";
                    document.getElementById("wrong").innerHTML ="* City should be selected";
                    document.fm.city.focus();
                    return false;
               }else{
                    document.getElementById("wrong").style.display ="none";
               }
               if(document.fm.tc.value == "")
               {
                    document.getElementById("wrong").style.display ="block";
                    document.getElementById("wrong").innerHTML ="* Training Center should be selected";
                    document.fm.tc.focus();
                    return false;
               }else{
                    document.getElementById("wrong").style.display ="none";
               }
               if(document.fm.sp.value == "0")
               {
                    document.getElementById("wrong").style.display ="block";
                    document.getElementById("wrong").innerHTML ="* Speciality should be selected";
                    document.fm.sp.focus();
                    return false;
               }else{
                    document.getElementById("wrong").style.display ="none";
               }
          }
     function addWeeksToDate(){
          var start = document.fm.start.value;
          var num = 8; 
          const newDate = new Date(start); 
          // Calculate the number of milliseconds in a week
          const millisecondsInWeek = 7 * 24 * 60 * 60 * 1000; 
          // Add the specified number of weeks to the date
          newDate.setTime(newDate.getTime() + (num * millisecondsInWeek)); 
          document.fm.finish.value = newDate;
     }
     function ValidateDates(){
        var start = document.fm.start.value;
        var finish = document.fm.finish.value;
        var num = 8; 
        const startDate = new Date(start); 
        const endDate = new Date(finish); 
        if(startDate.getTime() > endDate.getTime()){
            window.alert('End date must be after start date.');
            return false; 
        }
    }
     </script>
     </script>

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>  
          </div>
     </section>
     <?php 
    include('../php_en/connect.php');
    $open_dates = mysqli_query($connect, "SELECT * FROM `training_dates`");
    if($record = mysqli_fetch_array($open_dates)){
        $open_date = $record['train_open_date'];
        $close_date = $record['train_close_date'];
        $date = date('y-m-d');
        $today = new DateTime($date);
        $openDate = new DateTime($open_date);
        $closeDate = new DateTime($close_date);
        if(($today >= $openDate) && ($today <= $closeDate)){
            $open = "1"; 
        }else{
            $open = "0";
        }
    }
    ?>

     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="header-icons" align="right">
               <?php
                    if(isset($_SESSION['ID'])){
                         ?>
                    <a href="logout.php"  title="Logout"><i class="fa fa-sign-out"></i>&nbsp; Logout</a>
                         <?php
                    }else{
                         ?>
                    <a href="login.html"  title="Login"><i class="fa fa-user"></i>&nbsp; Login</a>
                         <?php
                    }
                    ?>
                    <a href="../apply_training.php"  title="Lang"><img src="../images/lang.png" style="width:18px; height:18px;">&nbsp;عربي</a>
               </div>
               <img class="nav navbar-right" src="../images/health_cluster.png" style="width:40%;" dir="right">
                    <br>
                    <br>
              <div class="navbar-header">
               <nav class="main-menu">
                    <ul>
                         <li><a href="index.php">Home</a></li>
                         <li><a href="index.php#about">Program</a></li>
                         <li><a href="index.php#team">Services</a></li>
                         <li class="current-list-item"><a href="apply_training.php">Apply</a></li>
                    </ul>
               </nav>
               </div>
                   
           </div>

          </div>
     </section>
     <?php
          if(isset($_SESSION['ID'])){
               $state = $_SESSION['TRAIN']; 
               $id = $_SESSION['ID'];
               $name = $_SESSION['NAME'];
               if($state == "no-request"){
     ?>

     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">
               <?php
                         if($open == "0"){
                         ?>
                         <div style="width: 100%; margin-top: 50px;" class="section-title">
                              <h2> Apply Training Closed  <small> Check for Open Registeration</small></h2>
                         </div>
                         <?php
                         } else if($open == "1") {
                         ?>
                         <div style="width: 100%; margin-top: 50px;" class="section-title">
                                   <h2> Apply Training<small> Fill all required data</small></h2>
                              </div>
                    <div class="col-sm-12">
                         <form id="contact-form" name="fm" role="form" action="../php_en/request.php" method="post" onSubmit="return Validate();" enctype="multipart/form-data">
                        <div class="col-md-12 col-sm-12" style="width: 100%;">
                        <span id="wrong" name="wrong" style="color: #AA5005;background-color:#FFFFFF; font-size: 15px; font-weight: 500; display:none;"></span>
                            <table width="100%">
                            <tr><td width="45%">
                                <label for="city" style="color:#FFFFFF; margin-bottom:-10px;">Choose City</label>    
                                <select id="city" name="city" style="height: 40px;" class="form-control" onchange="updateSecondSelect()">
                                    <option value="0"> -- Choose City -- </option>
                                    <option value="c1">Riyadh</option>
                                    <option value="c2">Artawiya</option>
                                    <option value="c3">Al-Zalafi</option>
                                    <option value="c4">Al-Ghat</option>
                                    <option value="c5">Al-Majamaea</option>
                                    <option value="c6">Tumir</option>
                                    <option value="c7">Hutat Sadir</option>
                                    <option value="c8">Ramah</option>
                                </select>
                            </td><td width="5%">&nbsp;</td>
                            <td width="45%">
                                <label for="tc" style="color:#FFFFFF;margin-bottom:-10px;">Choose Training Center</label>
                                <select id="tc" name="tc" style="height: 40px;" class="form-control">
                                    <option value="0">-- Choose Trainig Center --</option>
                                </select>
                            </td>
                        </tr>
                        <tr><td height="20">&nbsp;</td><td width="5%">&nbsp;</td><td height="20">&nbsp;</td></tr>
                        <tr><td width="45%"> 
                            <label for="sp" style="color:#FFFFFF;margin-bottom:-10px;">Choose Speciality</label>   
                            <select id="sp" name="sp" style="height: 40px;" class="form-control">
                                <option value="0"> -- Choose Special  -- </option>
                                <option>Artificial Intelligence</option>
                                <option>Business Administration</option>
                                <option>Business Accounting</option>
                                <option>Business Finance</option>
                                <option>Business HR</option>
                                <option>Business Marketing</option>
                                <option>Computer Network</option>
                                <option>Computer Science</option>
                                <option>Computer Science and Engineering</option>
                                <option>Customer Service</option>
                                <option>Cyber Security</option>
                                <option>Data Science</option>
                                <option>Database and Web Development</option>
                                <option>Graphic Design</option>
                                <option>Health Information Management Technology</option>
                                <option>Information Management</option>
                                <option>Information Systems</option>
                                <option>Information Technology</option>
                                <option>Management Information Systems</option>
                                <option>Multimedia and Web Technologies</option>
                                <option>Multimedia Design</option>
                                <option>Multimedia Designer</option>
                                <option>Programming</option>
                                <option>Programming and Databases</option>
                                <option>Software Engineer</option>
                                <option>Technical Support</option>
                                <option>Website and Mobile Development</option>
                                <option>N/A</option>
                                <option>Not Selected</option>
                                <option>Other Major</option>
                            </select>
                        </td><td width="5%">&nbsp;</td>
                        <td width="45%">
                            <label for="academic" style="color:#FFFFFF;margin-bottom:-10px;">Academic GPA</label>
                            <input type="number" step="0.01" class="form-control" placeholder="Type your GPA" style="height: 40px;" name="gpa" required="">
                         </td>
                    </tr>
                    <tr><td height="20">&nbsp;</td><td width="5%">&nbsp;</td><td height="20">&nbsp;</td></tr>
                    <tr>
                        <td width="45%">
                            <label for="identity" style="color:#FFFFFF;margin-bottom:-10px;">Identity Certificate Image</label>
                            <input id="identity" name="identity" type="file" style="height: 40px;" class="form-control" required="">
                            <small style="color:#CECECE;margin-top:-10px;">File should be an image</small>
                        </td><td width="5%">&nbsp;</td>
                        <td width="45%">
                            <label for="msg" style="color:#FFFFFF;margin-bottom:-10px;">University Letter </label>
                            <input id="msg" name="msg" type="file" style="height: 40px;" class="form-control" required="">
                            <small style="color:#CECECE;margin-top:-10px;">File should be PDF type</small>
                        </td>
                    </tr>
                    <tr >
                    <td width="45%">
                    <label for="start" style="color:#FFFFFF;margin-bottom:-10px;">Training Start Date</label>
                    <input type="date" class="form-control" placeholder="Start Training " id="start" name="start_date" onChange="return addWeeksToDate();" required="">                   
                    </td></td><td width="5%">&nbsp;</td><td width="45%">
                    <label for="finish" style="color:#FFFFFF;margin-bottom:-10px;">Training End Date</label>
                    <input type="date" class="form-control" placeholder="End Training " id="finish" name="end_date" onChange="return ValidateDates();" required="">
                    </td></tr>

                            </table>
                        </div>

                              <div style="margin-top:30px;" class="col-md-4 col-sm-12">
                                   <input style="font-weight: bold; font-size: 16px;" type="submit" class="form-control" name="Submit" value="Submit">
                              </div>
                         </form>
                         <?php
                              }
                         ?>
                    </div>

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                        <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>

                   

               </div>
          </div>
     </section>       
     <?php
        }else if($state == "wait"){
     ?>
<section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12" style="margin-top:50px;">
                         <h2>Your request has been submitted and is still under review.</h2>
                    </div>

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                        <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>
               </div>
          </div>
     </section>
<?php
     }else if($state == "Rejected"){
          ?>
     <section id="contact">
               <div class="container">
                    <div class="row">
     
                    <div class="col-sm-12" style="margin-top:50px;">
                              <h2>Your Training Request is rejected </h2>
                              <?php
                               include("php/connect.php");
                               $sel_reason = mysqli_query($connect, "select * from `training_requests` where `stud_id` = '$id' and `request_status` = '$state'");
                               if($sel_rows = mysqli_fetch_array($sel_reason)){
                                   $reason = $sel_rows['reject_reason'];
                                   echo "<h3 style='color:#FEFEFE;'>$reason</h3>";
                               }
                               $new_state1 = "no-request";
                               //// reset the status of the student, and cancel his request
                               $update_state = mysqli_query($connect, "update `student` set `stud_get_training` = '$new_state1' where `stud_id` = '$id'");  
                               $cancel_request = mysqli_query($connect, "delete from `training_requests` where `stud_id`= '$id'");                   
                              ?>
     
                         </div>
     
                         <div class="col-md-6 col-sm-12">
                             <div class="contact-image">
                             <figure>
                                  <span></span>
                                  </figure>
                             </div>
                        </div>
                    </div>
               </div>
          </section>
     <?php
          }else if($state == "Approved"){
          include("../php_en/connect.php");
          $state2="Done";
          $state3="Submit";
          $select = mysqli_query($connect, "select * from `training_requests` where `stud_id` = '$id' and (`request_status` = '$state' 
          OR `request_status` = '$state2' OR `request_status` = '$state3')");
          $num = mysqli_num_rows($select);
          if($num != 0){
               $record = mysqli_fetch_array($select);
               $branch = $record['branch_name'];
               $sp = $record['stud_speciality'];
               $start = $record['train_start_date'];
               $end = $record['train_end_date'];
               $manage = $record['training_management'];
               $requestState = $record['request_status'];
               $details = mysqli_query($connect, "select * from `branch` where `health_cluster` like '$branch'");
               if($found = mysqli_fetch_array($details)){
                    $branch_email = $found['branch_email'];
                    $branch_loc = $found['branch_location'];
               }
          }       
     ?>
     <section id="contact">
          <div class="container">
               <div class="row">
               <div class="col-sm-12" style="margin-top:50px;">
                         <h2>Welcome  <?php echo $name; ?> </h2>
                         <h2>Your Training Request is Approved</h2>
                         <table border="1" width="100%">
                              <tr align="center" style="background:rgb(85, 134, 143); color:#FFFFFF;">
                                   <td><h4 style="color:#FFFFFF;">Branch</h4></td><td><h4 style="color:#FFFFFF;">Branch Email</h4></td>
                                   <td><h4 style="color:#FFFFFF;">Branch Location</h4></td><td><h4 style="color:#FFFFFF;">Speciality</h4></td>
                                   <td><h4 style="color:#FFFFFF;">Start Date</h4></td><td><h4 style="color:#FFFFFF;">End Date </h4></td>
                                   <td><h4 style="color:#FFFFFF;">Starting Training Model</h4></td>
                                   <td><h4 style="color:#FFFFFF;">Working Card Request</h4></td>
                              </tr>
                              <tr align="center" style="background:#FFFFFF;">
                                   <td><h4 style="color:rgb(85, 134, 143);"><?php echo $branch; ?></h4></td>
                                   <td><h4 style="color:rgb(85, 134, 143);"><?php echo $branch_email; ?></h4></td>
                                   <td><h4><a style="color:rgb(130, 197, 209);" target="_blank" href="<?php echo $branch_loc; ?>">View Location</a></h4></td>
                                   <td><h4 style="color:rgb(85, 134, 143);"><?php echo $sp; ?></h4></td>
                                   <td><h4 style="color:rgb(85, 134, 143);"><?php echo $start; ?></h4></td>
                                   <td><h4 style="color:rgb(85, 134, 143);"><?php echo $end; ?></h4></td>
                                   <td><h4><a style="color:rgb(130, 197, 209);" target="_blank" href="../generate_pdf.php?id=<?php echo $id; ?>"> Start Training Form </a></h4></td>
                                   <td><h4><a style="color:rgb(130, 197, 209);" target="_blank" href="../images/extract_identity.pdf">Work Card Application</a></h4></td>

                              </tr>
                                   
                         </table>
                         <?php 
                         if((isset($SESSION['STATE']) && $SESSION['STATE'] == "Done") || $requestState == "Done"){
                              ?>
                              <h3 style="color:#FFFFFF;">Work Card Application Request is Executed</h3>
                         <?php
                         }else if($requestState == $state3){
                              ?>
                              <h3 style="color:#FFFFFF;">Your Work card application has been sent.</h3>
                         <?php
                         }else{
                              ?>
                              <h3 style="color:#FFFFFF;">You must fill out the Work Card Application form and then upload it here <a style="color:rgb(187, 238, 246);" target="_blank" href="upload_identity_request.php?id=<?php echo $id; ?>">Upload Application Request</a></h3>
                         <?php 
                         }
                         ?>                                           
                         </div>

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                        <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>
               </div>
          </div>
     </section> 
<?php
     }
  }else{
     ?>
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <h2>You should login to your account</h2>
                    </div>

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                        <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>
               </div>
          </div>
     </section> 
<?php
  }
?>

     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Riyadh Second Health Cluster</h2>
                              </div>
                              <address>
                                   <p>Kingdom of Saudi Arabia</p>
                              </address>

                              <ul class="social-icon">
                              <li><a href="https://www.facebook.com/Cluster2Riyadh" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://ca.linkedin.com/company/second-health-cluster" class="fa fa-linkedin"></a></li>
                                   <li><a href="https://www.instagram.com/cluster2_riyadh/" class="fa fa-instagram"></a></li>
                                   <li><a href="https://x.com/Cluster2_Riyadh" class="fa fa-twitter"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2024 KFMC</p>
                                  
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Contact Info. </h2>
                              </div>
                              <address>
                                   <p><i class="fa fa-phone"></i> &nbsp;8001277000</p>
                                   <p><i class="fa fa-envelope"></i> &nbsp;<a href="mailto:KFMC">info@rc2.med.sa</a></p>
                              </address>

                         </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                         <div class="footer_menu" style="margin-top: -40px;">
                              <h2 style="color: #FFFFFF;">Important Links</h2>
                              <p><a href="https://www.moh.gov.sa/Pages/Default.aspx">Ministry of Health </a></p>
                              <p><a href="https://www.kfmc.med.sa/">King Fahad Medical City</a></p>
                              <p><a href="https://shc.gov.sa/Arabic/Pages/default.aspx">Saudi Health Council</a></p>
                              <p><a href="https://www.who.int/ar/home">World Health Organization</a></p>                                  
                         </div>
                    </div>
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="../js/jquery.js"></script>
     <script src="../js/bootstrap.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/smoothscroll.js"></script>
     <script src="../js/custom.js"></script>

</body>
</html>