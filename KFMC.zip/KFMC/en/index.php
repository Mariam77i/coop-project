<!DOCTYPE html>
<html lang="en">
<head>
     <title>التجمع الصحي الثاني</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="../css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/font-awesome.min.css">
     <link rel="stylesheet" href="../css/owl.carousel.css">
     <link rel="stylesheet" href="../css/owl.theme.default.min.css">
     <link href="../images/logo.png" rel="icon" type="image/png" />

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="../css/main.css">
     <link rel="stylesheet" href="../css/templatemo-style.css">

     <script>
          function clearCookies() 
          { 
          const cookies = document.cookie.split(";");
          for (let i = 0; i < cookies.length; i++) 
          { 
               const cookie = cookies[i]; 
               const eqPos = cookie.indexOf("="); 
               const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie; 
               document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/"; 
          } 
          }
     setInterval(clearCookies, 60 * 60 * 1000); // 60 minutes * 60 seconds * 1000 milliseconds
     </script>
     <style>
          body.lock-scroll { 
              overflow: hidden;
               /* Disable scrolling */ 
              }
         .rectangle { 
              width: 200px; 
              height: 250px;
              background-color: #FFFFFF; 
              border: 2px solid #d9d9d9; 
              transition: border-color 0.3s, box-shadow 0.3s;
              padding-top: 30px;
              } 
              .rectangle:hover { 
              border-color: #1596D8; 
              box-shadow: 0 0 20px #1596D8; 
              }
    </style>

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>  
          </div>
     </section>
     <?php 
    include('../php_en/connect.php');
    $open_dates = mysqli_query($connect, "SELECT * FROM `training_dates`");
    if($record = mysqli_fetch_array($open_dates)){
        $open_date = $record['train_open_date'];
        $close_date = $record['train_close_date'];
        $date = date('y-m-d');
        $today = new DateTime($date);
        $openDate = new DateTime($open_date);
        $closeDate = new DateTime($close_date);
        if(($today >= $openDate) && ($today <= $closeDate)){
            $open = "1"; 
        }else{
            $open = "0";
        }
    }
    ?>
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
          <div class="header-icons" align="left">
                <?php
                    if($open == "1"){
                ?>
                    <h4 style="color:#5E9EAA;">Training Registration is Open (<?php echo $open_date; ?> To <?php echo $close_date; ?>)</h4>
                    <?php
                        }else if($open == "0"){
                    ?>
                    <h4 style="color:#f14851;">Training Registeration is Closed</h4>
                    <?php
                        }
                    ?>

            </div>
               <div class="header-icons" align="right">
                    <a href="login.html"  title="Login"><i class="fa fa-user"></i>&nbsp; Login</a>
                    <a href="../index.php"  title="Lang"><img src="../images/lang.png" style="width:18px; height:18px;">&nbsp;عربي</a>
               </div>
               <img class="nav navbar-right" src="../images/health_cluster.png" style="width:40%;" dir="right">
               <br>
               <br>
              <div class="navbar-header">
               <nav class="main-menu">
                    <ul>
                         <li><a href="index.php">Home</a></li>
                         <li><a href="index.php#about">Program</a></li>
                         <li><a href="index.php#team">Services</a></li>
                         <li><a href="apply_training.php">Apply</a></li>
                    </ul>
               </nav>
               </div>       
           </div>
          </div>
          <div class="fixed-icon"> 
               <a href="https://api.whatsapp.com/send/?phone=9668001277000&text&type=phone_number&app_absent=0">
                    <img src="../images/customer_service.png" alt="Icon" style="width:90%; height: 90%;"></a>
          </div>
     </section>
     <!-- HOME -->
     <section id="home">
          <div class="row">
                    <div class="owl-carousel owl-theme home-slider">
                         <div class="item item-first">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1>Training Types  </h1>
                                             <h3 style="font-weight: bold; font-size: 18px;">Learn about the types of training available</h3>
                                             <a href="#team" style="font-weight: bold; font-size: 18px;" class="section-btn btn btn-default smoothScroll">Training Types</a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-second">
                              <div class="caption">
                                   <div class="container">
                                        <div>
                                             <h1 style="margin-left: 600px;"> Training Goals</h1>
                                             <h3 style="font-weight: bold; font-size: 18px;margin-left: 600px;">Learn about the training goals</h3>
                                             <a style="font-weight: bold; font-size: 18px;margin-left: 600px;" href="#about" class="section-btn btn btn-default smoothScroll">Training Goals</a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-third">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1>Apply Training </h1>
                                             <h3 style="font-weight: bold; font-size: 18px;">Go to register for one of our training programs</h3>
                                             <a style="font-weight: bold; font-size: 18px;" href="apply_training.php" class="section-btn btn btn-default smoothScroll">Apply</a>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
          </div>
     </section>


     <!-- ABOUT -->
     <section id="about">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="about-info">
                              <h2>About the program</h2>

                              <figure>
                                   <span><i class="fa fa-users"></i></span>
                                   <figcaption>
                                        <h3>Program Goals</h3>
                                        <br>
                                   <ul>
                                        <li style="margin-left: 75px;" align="justify">
                                             Supporting students by aligning academic study with practical application in a real work environment.
                                        </li>
                                        <li style="margin-left: 75px;" align="justify">
                                             Raising the level of knowledge and specialized and personal skills among university students by providing them with the opportunity to acquire new skills and raise the level of creative thinking and the ability to work in a team.                                        </li>
                                        <li style="margin-left: 75px;" align="justify">
                                             Enabling national cadres to practice their specializations in accordance with the best professional practices.
                                        </li>
                                        <li style="margin-left: 75px;" align="justify">
                                             Enabling them to practice specialized skills, including decision-making and problem-solving skills, in the work environment.                                        </li>
                                        <li style="margin-left: 75px;" align="justify">
                                             Strengthening the strategic relationship with universities and institutes inside and outside the Kingdom.                                        </li>
                                        <li style="margin-left: 75px;" align="justify">
                                             Supporting university education outcomes to keep pace with labor market needs.                                        </li>
                                   </ul>
                                   </figcaption>
                              </figure>

                              <figure>
                                   <span><i class="fa fa-file"></i></span>
                                   <figcaption>
                                        <h3> Required Documents </h3>
                                        <br>
                                   <ul>
                                        <li style="margin-left: 75px; padding-left:30px;" align="justify">
                                             Filling out the training application form.
                                        </li>
                                        <li style="margin-left: 75px; padding-left:30px;" align="justify">
                                             A copy of the civil status card.
                                        </li>
                                        <li style="margin-left: 75px; padding-left:30px;" align="justify">
                                             A copy of the academic record.
                                        </li>
                                        <li style="margin-left: 75px; padding-left:30px;" align="justify">
                                             A letter from the university stating that the co-op training program is required, with the start and end dates of the training.
                                        </li>
                                   </ul>
                                   </figcaption>
                              </figure>
                         </div>
                    </div>

                    <div style="margin-top: 90px;" class="col-md-offset-1 col-md-4 col-sm-12">
                         <figure>
                              <span><i class="fa fa-info"></i></span>
                              <figcaption style="margin-top: 30px;">
                                   <h3>Policy</h3>
                                   <p align="justify" style="margin-top:40px;">
                                        This policy applies to national competencies from students of internal and external universities, institutes and colleges who are required to complete the cooperative training and practical application requirement before graduation.
                                   </p>
                              </figcaption>
                         </figure>
                         <figure>
                              <span><i class="fa fa-check"></i></span>
                              <figcaption>
                                   <h3>Meet the admission requirements</h3>
                                   <br>
                              <ul>
                                   <li align="justify">
                                        Compatibility of the specialization with the fields approved in cooperative training
                                   </li>
                                   <li align="justify">
                                        Admission Requirements: The training period required by the university should not be less than 8 weeks.
                                   </li>
                                   <li align="justify">
                                        The applicant must be a Saudi national.
                                   </li>
                                   <li align="justify">
                                        The applicant must not have graduated and met the requirements of the cooperative training program.
                                   </li>
                              </ul>
                              </figcaption>
                         </figure>
                    </div>

               </div>
          </div>
     </section>


     <!-- TEAM -->
     <section style="background: #ffffff;" id="team">
          <div class="container">
               <div class="row" align="center">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>  Services  </h2>
                         </div>
                    </div>
                    <table width="70%" style="margin-left: 100px;"><tr>
                    <td>
                    <div class="rectangle">
                         <div align="center">
                              <a href="nearest_branch.html"><img src="../images/nearby.png" style="height:100px; width:100px; padding-top: 10px;" class="img-responsive" alt=""></a>
                         </div>
                         <h3 align="center"><a href="nearest_branch.html">Nearest Center</a></h3>
                    </div>
               </td><td>
                    <div class="rectangle">
                         <div align="center">
                              <a href="all_branches.html"><img src="../images/branches.png" style="height:100px; width:100px; padding-top: 10px;" class="img-responsive" alt=""></a>
                         </div>
                         <h3 align="center"><a href="all_branches.html">Health Centers</a></h3>
                    </div>
               </td><td>
                    <div class="rectangle">
                         <div align="center">
                              <a href="about_health.html"><img src="../images/logo.png" style="height:100px; width:100px; padding-top: 10px;" class="img-responsive" alt=""></a>
                         </div>
                         <h3 align="center"><a href="about_health.html"> About Health Centers</a></h3>
                    </div>
               </td></tr></table>
               </div>
          </div>
     </section>

     <!-- Courses -->
     <section id="courses">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1> Activities <small style="color: #1596D8; font-size: 15px;">Upcoming Activities</small></h1>
                         </div>

                         <div class="owl-carousel owl-theme owl-courses">
                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 18-12-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">World Arabic Language Day</a></h3></td>
                                                       <td width="40%"><img src="../images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                            <a href="activity_details.php?name=World Arabic Language Day&date=18-12-2024"><span>View More</span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 16-12-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">World Human Rights Day</a></h3></td>
                                                       <td width="40%"><img src="../images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                                 <a href="activity_details.php?name=World Human Rights Day&date=16-12-2024"><span>View More </span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 25-12-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">World Boss Day</a></h3></td>
                                                       <td width="40%"><img src="../images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                            <a href="activity_details.php?name=World Boss Day&date=25-12-2024"><span>View More </span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image" style="border: 2px solid #1596D8; border-radius: 5px; padding: 10px;" dir="rtl">
                                                    <table>
                                                       <tr><td dir="rtl"  style="color:#1596D8;"><i class="fa fa-calendar" style="color:#1596D8;"></i> &nbsp; 01-10-2024 </td><td>&nbsp;</td></tr>
                                                       <tr><td width="60%"><h3 dir="rtl"><a href="#"  style="color:#1596D8;">World Coffee Day</a></h3></td>
                                                       <td width="40%"><img src="../images/logo.png" class="img-responsive" alt=""></td></tr>
                                                       <tr><td>
                                                            <div class="courses-price">
                                                                 <a href="activity_details.php?name=World Coffee Day&date=01-10-2024"><span>View More </span></a>
                                                            </div>
                                                       </td><td>&nbsp;</td></tr>
                                                   </table> 
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                         </div>
               </div>
          </div>
     </section>

     <section id="testimonial">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>Accreditations and Awards<small style="color: #1596D8; font-size: 15px;">Quality Certificates and Awards</small></h2>
                         </div>
                         <div class="owl-carousel owl-theme owl-client">
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify2.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify1.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify3.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify4.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify5.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify6.gif" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify7.jpg" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify8.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify9.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify10.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify11.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify12.jpg" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify13.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify14.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item" style="background: transparent;">
                                        <img src="../images/certify15.png" style="height:100px; width:100px;" alt="">
                                   </div>
                              </div>
                         </div>
               </div>
          </div>
     </section>
     


     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Riyadh Second Health Cluster</h2>
                              </div>
                              <address>
                                   <p>Kingdom of Saudi Arabia</p>
                              </address>

                              <ul class="social-icon">
                              <li><a href="https://www.facebook.com/Cluster2Riyadh" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://ca.linkedin.com/company/second-health-cluster" class="fa fa-linkedin"></a></li>
                                   <li><a href="https://www.instagram.com/cluster2_riyadh/" class="fa fa-instagram"></a></li>
                                   <li><a href="https://x.com/Cluster2_Riyadh" class="fa fa-twitter"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2024 KFMC</p>
                                  
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Contact Info. </h2>
                              </div>
                              <address>
                                   <p><i class="fa fa-phone"></i> &nbsp;8001277000</p>
                                   <p><i class="fa fa-envelope"></i> &nbsp;<a href="mailto:KFMC">info@rc2.med.sa</a></p>
                              </address>

                         </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                         <div class="footer_menu" style="margin-top: -40px;">
                              <h2 style="color: #FFFFFF;">Important Links</h2>
                              <p><a href="https://www.moh.gov.sa/Pages/Default.aspx">Ministry of Health </a></p>
                              <p><a href="https://www.kfmc.med.sa/">King Fahad Medical City</a></p>
                              <p><a href="https://shc.gov.sa/Arabic/Pages/default.aspx">Saudi Health Council</a></p>
                              <p><a href="https://www.who.int/ar/home">World Health Organization</a></p>                                  
                         </div>
                    </div>
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="../js/jquery.js"></script>
     <script src="../js/bootstrap.min.js"></script>
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/smoothscroll.js"></script>
     <script src="../js/custom.js"></script>

</body>
</html>