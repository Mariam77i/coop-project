<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <title>التجمع الصحي الثاني</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link href="images/logo.png" rel="icon" type="image/png" />

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/main.css">
     <link rel="stylesheet" href="css/templatemo-style.css">
     <script src="js/script.js"></script>
     <style>
          .rectangle { 
                    height: 40px;
                    border: 1px solid #d9d9d9;
                    border-radius: 5px; 
                    transition: border-color 0.3s, box-shadow 0.3s;
                    padding: 5px;
               }
          .rectangle:hover { 
                    color:#CCCCCC;
                    border-color: #1596D8; 
                    border-radius: 5px;
                    box-shadow: 0 0 20px #1596D8; 
               }
     </style> 
     <script>
     function Validate(){
        var manage = document.fm.manage.value;
        if(manage == "0"){
            window.alert('يجب اختيار إدارة التدريب');
            return false; 
        }
    }
     </script>

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>  
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="header-icons" align="right">
               <?php
                    if(isset($_SESSION['AID'])){
                         ?>
                    <a href="logout.php"  title="Logout"><i class="fa fa-sign-out"></i>&nbsp; خروج</a>
                         <?php
                    }else{
                         ?>
                    <a href="login.html"  title="Login"><i class="fa fa-user"></i>&nbsp; دخول</a>
                         <?php
                    }
                    ?>
               <a href="en/admin.php"  title="Lang"><img src="images/lang.png" style="width:18px; height:18px;">&nbsp;EN</a>
                    
               </div>
               <img class="nav navbar-right" src="images/health_cluster.png" style="width:40%;" dir="right">
                    <br>
                    <br>
              <div class="navbar-header">
               <nav class="main-menu">
                    <ul>
                         <li><a href="index.php">الرئيسية</a></li>
                         <li><a href="index.php#about">البرنامج</a></li>
                         <li><a href="index.php#team">الخدمات</a></li>
                    </ul>
               </nav>
               </div>
                   
           </div>

          </div>
     </section>

     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">
                    <div class="col-sm-12">
                              <div style="margin-top: 20px;" dir="rtl" class="section-title">
                            <?php
                                if(!isset($_SESSION['AID'])){
                            ?>
                            <h2> يجب أن تقوم بتسجيل الدخول لتفعيل حسابك</h2>
                            <?php
                                }else{
                            ?>
                         <h4 dir="ltr"><a class="rectangle" href="train_dates.php">فتح وإغلاق التدريب </a> 
                         &nbsp; &nbsp; <a class="rectangle" href="approved_students.php">الطلبات المقبولة </a>
                         </h4>
                             <h2>  المشرف <small>استعراض طلبات التدريب</small></h2>
                              </div>   
                        <div style="margin-top: 20px; width: 100%;">
                        <?php
                            include("php/connect.php");
                            $state = "wait";
                            $sql = mysqli_query($connect, "select * from `training_requests` where `request_status` = '$state'");
                            while($record = mysqli_fetch_array($sql)){
                                $reqDate = $record['request_date'];
                                $reqMessage = $record['college_msg_file'];
                                $identity = $record['identity_img'];
                                $specail = $record['stud_speciality'];
                                $branch = $record['branch_name'];
                                $start_date = $record['train_start_date'];
                                $end_date = $record['train_end_date'];
                                $studID = $record['stud_id'];
                                $reqID = $record['request_id'];
                                $sel_student = mysqli_query($connect, "select * from `student` where `stud_id` = '$studID'");
                                if($found = mysqli_fetch_array($sel_student)){
                                    $name = $found['stud_name'];
                                    $phone = $found['stud_phone'];
                                    $email = $found['stud_email'];
                                }
                            ?>
                            <br>
                            <form id="contact-form" name="fm" role="form" action="php/accept_request.php" method="post">
                            <div style="border: 2px solid #FFFFFF; padding: 10px; width: 100%; border-radius:20px;
                            background: linear-gradient(to right, #909090, #105968);" dir="rtl">
                                <h3 style="color: #f9f9f9;"><font color="#454545">الطالب/ة:</font> <?php echo $name; ?>
                                <small style="color: #f9f9f9;">&nbsp;&nbsp;(<?php echo $reqDate; ?>)</small></h3>
                                <table width="100%"><tr>
                                    <td width="50%"><h4><font color="#CCCCCC">البريد الالكتروني:</font> <?php echo $email; ?></h4></td>
                                    <td width="50%"><h4><font color="#CCCCCC">الهاتف:</font> <?php echo $phone; ?></h4></td>
                                    <input type="hidden" name="reqID" value="<?php echo $reqID; ?>">
                                    <input type="hidden" name="studID" value="<?php echo $studID; ?>">
                                </tr>
                                <tr>
                                    <td width="50%"><h4><font color="#CCCCCC">التخصص: </font><?php echo $specail; ?></h4></td>
                                    <td width="50%"><h4><font color="#CCCCCC">رقم الهوية: </font><a href="<?php echo 'https://gradproject2024.serv00.net/kfmc/' . $identity; ?>" target="_blank">عرض البطاقة </a></h4></td>
                                </tr></table>
                                <table width="100%"><tr>
                                    <td><h4><font color="#CCCCCC">رسالة الجامعة:</font> <a href="<?php echo 'https://gradproject2024.serv00.net/kfmc/' . $reqMessage; ?>" target="_blank">عرض خطاب الجامعة </a></h4></td>
                                    <td width="50%"><h4><font color="#CCCCCC">الفرع المطلوب: </font><?php echo $branch; ?></h4></td>
                                </tr></table>
                                <table width="100%"><tr>
                                    <td><h4><font color="#CCCCCC"> تاريخ التدريب:</font> <?php echo $start_date; ?> &nbsp; إلى &nbsp; <?php echo $end_date; ?></h4></td>
                                    <td width="50%"><h4><table><tr><td><font color="#CCCCCC"> اختر إدارة التدريب: &nbsp;</font></td>
                                   <td><select name="manage" id="manage" class="form-control">
                                        <option>ادارة مكتب المدير العام التنفيذي</option>
                                        <option>⁠ادارة التخطيط والتطوير</option>
                                        <option>⁠ادارة الشؤون القانونيه</option>
                                        <option>⁠ادارة مكتب ذكاء الاعمال </option>
                                        <option>⁠ادارة الموارد الماليه الذاتيه</option>
                                        <option>⁠ادارة العلاقات العامه والاتصال المؤسسي </option>
                                        <option>⁠ادارة المتابعة  </option>
                                   </select></td></tr></table>
                                    </h4></td>
                                </tr></table>
                              
                                <table width="100%"><tr>
                                   <td width="50%" align="center">
                                   <h4><input type="image" src="images/approve.png" alt="Submit" style="width:50px; height:50px;"></td>
                                    <td width="50%" align="right"><h4><a href="reject_reason.php?req=<?php echo $reqID; ?>&stud=<?php echo $studID; ?>">
                                    <img src="images/reject.png"></a></h4></td>
                                </tr></table>
                            </div>
                            </form>
                        <?php
                        }
                            }
                        ?>
                        </div>
                             </div>
                        
                    </div>
                    

                    <div class="col-md-6 col-sm-12">
                        <div class="contact-image">
                             <figure>
                             <span></span>
                             </figure>
                        </div>
                   </div>

                   

               </div>
          </div>
     </section>       


     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>حول تجمع الرياض الصحي الثاني </h2>
                              </div>
                              <address>
                                   <p><i class="fa fa-phone"></i> &nbsp;8001277000</p>
                                   <p><i class="fa fa-envelope"></i> &nbsp;<a href="mailto:KFMC">info@rc2.med.sa</a></p>
                              </address>


                              <ul class="social-icon">
                                   <li><a href="https://www.facebook.com/Cluster2Riyadh" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://ca.linkedin.com/company/second-health-cluster" class="fa fa-linkedin"></a></li>
                                   <li><a href="https://www.instagram.com/cluster2_riyadh/" class="fa fa-instagram"></a></li>
                                   <li><a href="https://x.com/Cluster2_Riyadh" class="fa fa-twitter"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2024 KFMC</p>
                                  
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>معلومات الاتصال</h2>
                              </div>
                              <address>
                                   <p>+8001277000</p>
                                   <p><a href="mailto:KFMC">info@rc2.med.sa​</a></p>
                              </address>
                         </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                         <div class="footer_menu" style="margin-top: -40px;">
                              <h2 style="color: #FFFFFF;">روابط هامة</h2>
                                   <p><a href="https://www.moh.gov.sa/Pages/Default.aspx"> وزارة الصحة </a></p>
                                   <p><a href="https://www.kfmc.med.sa/">مدينة الملك فهد الطبية</a></p>
                                   <p><a href="https://shc.gov.sa/Arabic/Pages/default.aspx"> المجلس الصحي السعودي </a></p> 
                                   <p><a href="https://www.who.int/ar/home">منظمة الصحة العالمية  </a></p>                                  
                                 
                         </div>
                    </div>

                   
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>