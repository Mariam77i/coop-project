<?php
    session_start();
    include("connect.php");
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    if(!isset($_POST['email']) || !isset($_POST['pass'])){
            echo "<script>alert('Fill required inputs'); window.location.href = '../en/login.html' </script>";
    }else{
        /// first check if a student found with the email and password
        $select = mysqli_query($connect, "select * from `student` where `stud_email` = '$email' AND `stud_pass` = '$pass'");
        $num = mysqli_num_rows($select);
        if($num != 0){
            $record = mysqli_fetch_array($select);
            $_SESSION['ID'] = $record['stud_id'];
            $_SESSION['NAME'] = $record['stud_name'];
            $_SESSION['EMAIL'] = $record['stud_email'];
            $_SESSION['PHONE'] = $record['stud_phone'];
            $_SESSION['TRAIN'] = $record['stud_get_training'];
            echo "<script> window.location.href = '../en/apply_training.php'; </script>";
        }else{
            /// check if an admin found
            $select = mysqli_query($connect, "select * from `admin` where `admin_email` = '$email' AND `admin_pass` = '$pass'");
            $num = mysqli_num_rows($select);
            if($num != 0){
                $record = mysqli_fetch_array($select);
                $_SESSION['AID'] = $record['admin_id'];
                echo "<script> window.location.href = '../en/admin.php'; </script>";    
            }else{
                $select = mysqli_query($connect, "select * from `security` where `security_email` = '$email' AND `security_pass` = '$pass'");
                $num = mysqli_num_rows($select);
                if($num != 0){
                    $record = mysqli_fetch_array($select);
                    $_SESSION['SID'] = $record['security_id'];
                    echo "<script> window.location.href = '../en/security.php'; </script>";    
                }else{
                    /// No user found
                    echo "<script>alert('User not found'); window.location.href = '../en/login.html' </script>";
                }
            }
        }        
    }
?>