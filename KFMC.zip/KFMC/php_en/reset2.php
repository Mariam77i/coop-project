<?php
include("connect.php");
$email = $_POST['email'];
$pass = $_POST['pass'];

///// check if the Email is found ///////////////
$select = mysqli_query($connect, "select * from `student` where `stud_email` = '$email'");
$rows = mysqli_num_rows($select);
if($rows == 0){
    $select = mysqli_query($connect,"select * from `admin` where `admin_email`= '$email'");
    $rows = mysqli_num_rows($select);
    if($rows == 0){
        echo "<script> window.location.href = '../en/login.html'; alert('Email not found'); </script>"; 
    }else{
        $select = mysqli_query($connect,"update `admin` set `admin_pass`= '$pass' where `admin_email`= '$email'");
        echo "<script> window.location.href = '../en/login.html'; alert('Your Password is reset'); </script>";
    }
}else{
    $select = mysqli_query($connect,"update `student` set `stud_pass`= '$pass' where `stud_email`= '$email'");
    echo "<script> window.location.href = '../en/login.html'; alert('Your Password is reset'); </script>";
}             
?>