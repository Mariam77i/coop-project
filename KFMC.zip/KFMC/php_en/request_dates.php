<?php
include("connect.php");
$start = $_POST['start_date'];
$end = $_POST['end_date'];

///// update request ///////////////
$delete = mysqli_query($connect, "Delete from `training_dates`");
$insert =mysqli_query($connect, "insert into `training_dates` (`train_open_date`,`train_close_date`)
values ('$start', '$end')");
echo "<script> window.location.href = '../en/admin.php'; </script>";          
?>