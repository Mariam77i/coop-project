<?php
        session_start();
        include("connect.php");
        $name = $_POST['name'];
        $univ = $_POST['univ'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $pass = $_POST['pass'];
        $sp = $_POST['sp'];
        if(!isset($_POST['name']) || !isset($_POST['univ']) || !isset($_POST['email']) || !isset($_POST['phone']) || !isset($_POST['pass']) 
        || !isset($_POST['sp'])){
            $_SESSION['state'] = "1";
            $_SESSION['msg'] = "You should fill all required data";
            echo "<script> window.location.href = '../en/register.php'; </script>";
        }else{
            /// first check if a student found with the same email
            $select = mysqli_query($connect, "select * from `student` where `stud_email` = '$email' OR `univID` = '$univ' ");
            $num = mysqli_num_rows($select);
            if($num != 0){
                $_SESSION['state'] = "2";
                $_SESSION['msg'] = "Email or University ID is already used";
                echo "<script> window.location.href = '../en/register.php'; </script>";
            }else{
                /// first check if a student found with the same phone
                $select = mysqli_query($connect, "select * from `student` where `stud_phone` = '$phone' ");
                $num = mysqli_num_rows($select);
                if($num != 0){
                    $_SESSION['state'] = "3";
                    $_SESSION['msg'] = "Phone is already used";
                    echo "<script> window.location.href = '../en/register.php'; </script>";    
                }else{
                    /// first check if the supervisor has the same email
                    $select = mysqli_query($connect, "select * from `admin` where `admin_email` = '$email' ");
                    $num = mysqli_num_rows($select);
                    if($num != 0){
                        $_SESSION['state'] = "2";
                        $_SESSION['msg'] = "Email is already used";
                        echo "<script> window.location.href = '../en/register.php'; </script>";
                    }else{
                        /// first check if the supervisor has the same phone
                        $select = mysqli_query($connect, "select * from `admin` where `admin_phone` = '$phone' ");
                        $num = mysqli_num_rows($select);
                        if($num != 0){
                            $_SESSION['state'] = "3";
                            $_SESSION['msg'] = "Phone is already used";
                            echo "<script> window.location.href = '../en/register.php'; </script>";    
                        }else{
                    /// insert the new student
                    $insert = mysqli_query($connect, "insert into `student` (`stud_name`, `stud_email`, `stud_phone`,
                    `stud_speciality`, `stud_pass`, `univID`) values ('$name', '$email', '$phone', '$sp', '$pass', '$univ') ");
                    echo "<script>alert('New Student added successfully'); window.location.href = '../en/login.html' </script>";
                }
            }        
        }
    }
        }
?>