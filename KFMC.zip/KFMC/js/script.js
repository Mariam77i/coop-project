const items = {
    c1: ["الغدير", "النرجس", "الربيع", "الصحافة", "الفلاح", "الياسمين", "الوادي"
        , "الازدهار", "صلاح الدين", "المصيف", "المرسلات","حي الملك فهد", "المروج", "السليمانية", "النزهة", "الورود",
    "اشبيليا", "الخليج2", "الحمراء", "الخليج1", "قرطبة", "اليرموك الغربية", "حي الملك فيصل",
     "المونسية", "غرناطة", "الروضة1", "الروضة2", "النهضة الغربية", "الجنادرية الغربية", "الجنادرية الشرقية",
      "النظيم الشمالي", "النظيم الجنوبي", "الندوة", "هجرة سعد", "مركز الرقابة الصحية بالمطار",
       "عيادة المراسم الملكية", "عيادة الديوان الملكي", "عيادة صحة المرأة بحياة مول", "المنار", 
       "السلام", "النسيم الأوسط", "النسيم الجنوبي", "النسيم الشرقي", "النسيم الغربي", "السعادة", "الجزيرة"],
    c2: ["الارطاوية", "ام الجماجم", "مشرفة", "جراب", "البرزة", "مشذوبة", "مصدة سدير", "قاعية سدير",
         "مشلح", "مشاش عوض", "حويمضة", "ام سديرة", "برزان"],
    c3: ["القدس", "الخالدية", "الصديق", "الفاروق", "اليمامة", "علقه", "الثوير"],
    c4: ["مركز صحي الغاط", "مركز صحي مليح", "مركز صحي العبدلية"],
    c5: ["مركز صحي المطار", "مركز صحي المطار", "مركز صحي الفيحاء", "مركز صحي اليرموك", "مركز صحي البصيرة",
         "مركز صحي عبدالعزيز الشويعر", "مركز صحي حرمة", "مركز صحي الفيصلية", "مركز صحي المجمعة"],
    c6: ["مركز صحي تمير", "مركز ام رجوم "],
    c7: ["مركز حوطة سدير", "مركز صحي النهضة بسدير", "مركز صحي الشفاء بحوطة سدير", "مركز التويم",
         "مركز روضة سدير", "مركز صحي العطار", "مركز صحي الخطامة", "مركز صحي عودة سدير", "مركز صحي عشيرة سدير", "مركز صحي مبايض"],
    c8: ["حفر العتش", "الرمحية", "العيطليه", "الغيلانه", "المزيرع", "حفنة الطيري", "رماح", "شوية"],
};

function updateSecondSelect() {
    const firstSelect = document.getElementById("city");
    const secondSelect = document.getElementById("tc");
    const selectedCategory = firstSelect.value;

    // Clear previous options
    //secondSelect.innerHTML = '<option value="0">-- اختر مركز تدريب --</option>';

    if (selectedCategory) {
        // Add new options based on the selected category
        items[selectedCategory].forEach(item => {
            const option = document.createElement("option");
            option.value = item;
            option.textContent = item;
            secondSelect.appendChild(option);
        });
    }
}
function updateSecondSelect2() {
    const firstSelect = document.getElementById("city");
    const secondSelect = document.getElementById("tc");
    const selectedCategory = firstSelect.value;

    // Clear previous options
    secondSelect.innerHTML = '<option value="0">-- Choose Training Center --</option>';

    if (selectedCategory) {
        // Add new options based on the selected category
        items[selectedCategory].forEach(item => {
            const option = document.createElement("option");
            option.value = item;
            option.textContent = item;
            secondSelect.appendChild(option);
        });
    }
}
function viewCity(){
    const typeSelect = document.getElementById("tp");
    const cityDiv = document.getElementById("branch");
    const selectedType = typeSelect.value;
    if(selectedType == 2){
        cityDiv.style.display = "block";
    }else if(selectedType == 1){
        cityDiv.style.display = "none";
    }
}