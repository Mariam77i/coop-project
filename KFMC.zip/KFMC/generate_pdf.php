<?php
    // Set the content type to PDF
include('php/connect.php');
require_once('TCPDF/tcpdf.php');
header('Content-Type: application/pdf');

$studID = $_GET['id'];

// Create a PDF document
$pdf = new TCPDF('L', 'mm', 'A4', true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('KFMC');
$pdf->SetTitle('Arabic PDF Document');
$pdf->SetSubject('A Simple PDF with Arabic Text');
$pdf->SetKeywords('TCPDF, PDF, Arabic, PHP');

// Add a page
$pdf->AddPage();

// Set font with Arabic support
$pdf->SetFont('aealarabiya', '', 12);
// Arabic text
$arabicText1 = "وكالة الجامعة للشؤون الأكاديمية";
$arabicText2 = "وحدة التدريب الميداني";
$arabicText3 = "نموذج مباشرة طالبة متدربة";
$txt4 = "يعبأ من قبل مشرف/ة جهة التدريب";
$txt5 = "سعادة عميدة الكلية - السلام عليكم ورحمة الله وبركاته";
$txt6 = "نفيدكم أن الطالبة باشرت التدريب لدى جهتكم";
// Write the Arabic text to the PDF
$pdf->Write(0, $arabicText1, '', 0, 'R', true, 0, false, false, 0);
$pdf->Write(0, $arabicText2, '', 0, 'R', true, 0, false, false, 0);
$pdf->SetFont('aealarabiya', '', 20);
$pdf->Write(0, $arabicText3, '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, '', '', 0, 'C', true, 0, false, false, 0);
$pdf->SetFont('aealarabiya', '', 12);
$pdf->Write(0, $txt4, '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, $txt5, '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, $txt6, '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, '', '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, '', '', 0, 'C', true, 0, false, false, 0);
$pdf->Cell(50, 10, 'ادارة التدريب', 1, 0, 'C');
$pdf->Cell(40, 10, 'اسم المشرف على التدريب', 1, 0, 'C');
$pdf->Cell(30, 10, 'تاريخ مباشرة التدريب', 1, 0, 'C');
$pdf->Cell(60, 10, 'التخصص', 1, 0, 'C');
$pdf->Cell(30, 10, 'الرقم الجامعي', 1, 0, 'C');
$pdf->Cell(70, 10, 'اسم الطالبة المتدربة', 1, 0, 'C');
$pdf->Ln();
//// Read the approved student ////
$pdf->SetFont('aealarabiya', '', 10);
$sql = "SELECT `univID`, `stud_name`, r.stud_speciality, `train_start_date`, `training_management`
  FROM `student` s, `training_requests` r WHERE s.stud_id = r.stud_id AND s.stud_id = '$studID'"; // Example query
$result = $connect->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(50, 10, $row['training_management'], 1, 0, 'C');
        $pdf->Cell(40, 10, '', 1, 0, 'C');
        $pdf->Cell(30, 10, $row['train_start_date'], 1, 0, 'C');
        $pdf->Cell(60, 10, $row['stud_speciality'], 1, 0, 'C');
        $pdf->Cell(30, 10, $row['univID'], 1, 0, 'C');
        $pdf->Cell(70, 10, $row['stud_name'], 1, 0, 'C');
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0, 10, 'No data found', 1, 1, 'C');
 }
 $connect->close();

$pdf->SetFont('aealarabiya', '', 14);
$pdf->Write(0, '', '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, '', '', 0, 'C', true, 0, false, false, 0);
  
$html = <<<EOD
<h1 align="center" style="background-color:#1596D8;" >بيانات منسق جهة التدريب</h1>
<table dir="rtl" border="1">
  <tr align="center" style="padding:50px;"><td>&nbsp;</td><td>البريد الالكتروني</td><td>&nbsp;</td><td>اسم المشرف</td></tr>
  <tr align="center" style="padding:50px;"><td>&nbsp;</td><td>التوقيع</td><td>&nbsp;</td><td>رقم الجوال</td></tr>
  </table>
  <p>&nbsp;</p>
  <p>ختم جهة التدريب</p>
EOD;

// Print text using writeHTMLCell()
$pdf->writeHTMLCell(280, 0, '', '', $html, 0, 1, 0, true, '', false);


// Output the PDF
$pdf->Output('training_form.pdf', 'I'); // 'I' for inline display
?>