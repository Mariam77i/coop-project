<?php
include("connect.php");
if(isset($_POST["sel_city"]) && isset($_POST["sel_tc"])){
    $city = $_POST["sel_city"];
    $tc = $_POST["sel_tc"];
    ///// read the location  ///////////////
    $read = mysqli_query($connect, "select * from `branch` where `branch_city` like '$city' and 
    `health_cluster` like '$tc'");
    if($found = mysqli_fetch_array($read)){
        $location = $found['branch_location'];
    }
    echo "<script> window.location.href = '$location'; </script>"; 
}else{
    echo "<script>alert('اختر مرة أخرى'); window.location.href = '../all_branches.html' </script>";
}
          
?>