<?php
    session_start();
    include("connect.php");
    $id = $_SESSION['ID'];
    $tc = $_POST['tc'];
    $sp = $_POST['sp'];
    $start = $_POST['start_date'];
    $finish = $_POST['end_date'];
    $date = date('y-m-d');
    $gpa = $_POST['gpa'];

    if($sp == "0"){ $sp = "Not Selected";}
    if($tc == "0"){ $tc = "Not Selected";}

        $requestID = "1";
        $select_req = mysqli_query($connect, "select * from `training_requests` order by `request_id` desc");
        if($found = mysqli_fetch_array($select_req)){
            $reqID = $found['request_id']; 
            $reqID = $reqID + 1; 
        }
        $added_identity_name = "iden" . $reqID; 
        $added_college_msg = "msg" . $reqID;
        if(isset($_FILES['identity']) && $_FILES['identity']['size'] >0)
        {
            $allowed = array('gif', 'png', 'jpg', 'jpeg');
            $tmp_name = $_FILES['identity']['tmp_name'];
            $file_name = $_FILES['identity']['name'];
            $ext = pathinfo($file_name, PATHINFO_EXTENSION);
            if (in_array($ext, $allowed)) {
                $readFile  = fopen($tmp_name, 'r');
                $file_data = fread($readFile, filesize($tmp_name));
                $file_data = addslashes($file_data);
                fclose($readFile);
                $file = "../files/" . $added_identity_name . "_" .$file_name;
                move_uploaded_file($tmp_name,"$file");
                $done1 = "1";
            }else{
                $done1 = "0";
                echo "<script>alert('Please choose valid identity image file'); window.location.href = '../apply_training.php' </script>"; 
            }
        }else{
            $done1 = "0";
            echo "<script>alert('Please choose Identity Image'); window.location.href = '../apply_training.php' </script>"; 
        } 
        if(isset($_FILES['msg']) && $_FILES['msg']['size'] >0)
        {
            $allowed2 = array('pdf');
            $tmp_name2 = $_FILES['msg']['tmp_name'];
            $file_name2 = $_FILES['msg']['name'];
            $ext2 = pathinfo($file_name2, PATHINFO_EXTENSION);
            if (in_array($ext2, $allowed2)) {
                $readFile2  = fopen($tmp_name2, 'r');
                $file_data2 = fread($readFile2, filesize($tmp_name2));
                $file_data2 = addslashes($file_data2);
                fclose($readFile2);
                $file2 = "../files/" . $added_college_msg . "_" .$file_name2;
                move_uploaded_file($tmp_name2,"$file2");
                $done2 = "1";
            }else{
                $done2 = "0";
                echo "<script>alert('Please choose valid College Letter file'); window.location.href = '../apply_training.php' </script>"; 
            }
        }else{
            $done2 = "0";
            echo "<script>alert('Please choose College Letter file'); window.location.href = '../apply_training.php' </script>"; 
        } 
        if($done1 == "1" && $done2 == "1"){
            $file = substr($file, 3);
            $file2 = substr($file2, 3);
            $add_request = mysqli_query($connect, "insert into `training_requests` (`stud_id`, `branch_name`, 
            `stud_speciality`,`gpa`,`identity_img`,`college_msg_file`, `request_date`,`train_start_date`, `train_end_date`) 
            values ('$id', '$tc','$sp', '$gpa', '$file', '$file2', '$date', '$start', '$finish')");
            //// update the student status ////
            $state = "wait";
            $_SESSION['TRAIN'] = "wait";
            $update = mysqli_query($connect, "update `student` set `stud_get_training` = '$state' where `stud_id` = '$id'");
            echo "<script>window.location.href = '../apply_training.php' </script>";
        }    
?>