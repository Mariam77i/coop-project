<?php
    $database = "m1501_kfmc";
    $username = "m1501_kfmc";
    $pass = "GradProject@2024";
    $host = "mysql3.serv00.com";
    $connect = mysqli_connect($host, $username, $pass, $database) or die ("Server connect error"); 
    mysqli_query($connect,"set names utf8");
?>