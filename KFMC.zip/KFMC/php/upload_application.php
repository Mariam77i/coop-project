<?php
    session_start();
    include("connect.php");
    $new_state = "Submit";

    $studID = $_POST['studID'];
    $added_file_name = "application" . $studID; 
        if(isset($_FILES['file']) && $_FILES['file']['size'] >0)
        {
            $allowed = array('gif', 'png', 'jpg', 'jpeg', 'pdf');
            $tmp_name = $_FILES['file']['tmp_name'];
            $file_name = $_FILES['file']['name'];
            $ext = pathinfo($file_name, PATHINFO_EXTENSION);
            if (in_array($ext, $allowed)) {
                $readFile  = fopen($tmp_name, 'r');
                $file_data = fread($readFile, filesize($tmp_name));
                $file_data = addslashes($file_data);
                fclose($readFile);
                $file = "../files/" . $added_file_name . "_" .$file_name;
                move_uploaded_file($tmp_name,"$file");
                $done1 = "1";
            }else{
                $done1 = "0";
                echo "<script>alert('Please choose valid application file'); window.location.href = '../apply_training.php' </script>"; 
            }
        }else{
            $done1 = "0";
            echo "<script>alert('Please choose application file'); window.location.href = '../apply_training.php' </script>"; 
        }  
        if($done1 == "1"){
            $file = substr($file, 3);
            $add_application = mysqli_query($connect, "update `training_requests` set
             `application_file` = '$file', `request_status` = '$new_state' where `stud_id` = '$studID'");
            $_SESSION['STATE'] = "Done";
            echo "<script>window.location.href = '../apply_training.php' </script>";
        }
?>