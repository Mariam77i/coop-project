<?php
include("connect.php");
$id = $_POST['reqID'];
$stud = $_POST['studID'];
$reason = $_POST['reason'];
$state = "Rejected";
/// read the student email ////
$read_email = mysqli_query($connect, "select * from `student` where `stud_id` = '$stud'");
if($rows = mysqli_fetch_array($read_email)){
    $email = $rows['stud_email'];
    $name = $rows['stud_name'];
}

///// change state ///////////////
$update = mysqli_query($connect, "update `training_requests` set `request_status` = '$state', 
`reject_reason` = '$reason' where `request_id` = '$id'");
$updateStud = mysqli_query($connect, "update `student` set `stud_get_training` = '$state' 
where `stud_id` = '$stud'");
ini_set('SMTP' , 'TPCENTER-PC');
        $title = "KFMC Identity Card";
        $body = "عزيزتي الطالبة " . $name . "\nلقد تم رفض طلب التدريب الخاصة بك" . "\n يرجى متابعة موقع التدريب لمعرفة اسباب الرفض";
        $email_from = "gradproject2024@gradproject2024.serv00.net";
        $headers = "From: " . $email_from;
        mail($email, $title , $body , $headers);
echo "<script> window.location.href = '../admin.php'; alert('Request Rejected'); </script>";             
?>