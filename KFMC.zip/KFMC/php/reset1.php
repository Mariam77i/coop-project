<?php
session_start();
include("connect.php");
$email = $_POST['email'];
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$code = substr(str_shuffle($permitted_chars), 0, 6);

///// check if the Email is found ///////////////
$select = mysqli_query($connect, "select * from `student` where `stud_email` = '$email'");
$rows = mysqli_num_rows($select);
if($rows == 0){
    $select = mysqli_query($connect,"select * from `admin` where `admin_email`= '$email'");
    $rows = mysqli_num_rows($select);
    if($rows == 0){
        echo "<script> window.location.href = '../reset_pass1.html'; alert('Email not found'); </script>"; 
    }else{
        ini_set('SMTP' , 'TPCENTER-PC');
        $title = "KFMC Reset Password OTP-code";
        $body = "Code: " . $code;
        $email_from = "gradproject2024@gradproject2024.serv00.net";
        $headers = "From: " . $email_from;
        mail($email, $title , $body , $headers);
        $_SESSION['EMAIL'] = $email;
        $_SESSION['CODE'] = $code;
        echo "<script> window.location.href = '../reset_pass2.php'; </script>";
    }
}else{
        ini_set('SMTP' , 'TPCENTER-PC');
        $title = "KFMC Reset Password OTP-code";
        $body = "Code: " . $code;
        $email_from = "gradproject2024@gradproject2024.serv00.net";
        $headers = "From: " . $email_from;
        mail($email, $title , $body , $headers);
        $_SESSION['EMAIL'] = $email;
        $_SESSION['CODE'] = $code;
        echo "<script> window.location.href = '../reset_pass2.php'; </script>";
    }             
?>