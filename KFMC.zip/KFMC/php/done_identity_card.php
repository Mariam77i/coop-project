<?php
include("connect.php");
$stud = $_GET['stud'];
$state = "Done";
/// read the student email ////
$read_email = mysqli_query($connect, "select * from `student` where `stud_id` = '$stud'");
if($rows = mysqli_fetch_array($read_email)){
    $email = $rows['stud_email'];
    $name = $rows['stud_name'];
}

///// change state ///////////////
$update = mysqli_query($connect, "update `training_requests` set `request_status` = '$state' where `stud_id` = '$stud'");
ini_set('SMTP' , 'TPCENTER-PC');
        $title = "KFMC Identity Card";
        $body = "عزيزتي الطالبة " . $name . "\nلقد تم تنفيذ طلب بطاقة العمل الخاصة بك";
        $email_from = "gradproject2024@gradproject2024.serv00.net";
        $headers = "From: " . $email_from;
        mail($email, $title , $body , $headers);
echo "<script> window.location.href = '../security.php'; alert('Request Done'); </script>"; 
             
?>